﻿using System.Globalization;
using System.Runtime.Intrinsics.X86;

namespace Question_11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter number: ");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] numbers = { 2, 5, 7, 8, 10 };
            int l = numbers.Length;
            int i = 0;

            for (i = 0; i < l; i++) ;
            {
                
                if (n == numbers[l - i-1])
                {
                    Console.WriteLine("Found");
                } 
            }

       

            Console.ReadLine();

        }
    }
}