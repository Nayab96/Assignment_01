﻿namespace Question_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter word:");
            string word = Console.ReadLine();

            int l = word.Length;
            string reverse = "";

            for(int i=l-1; i >= 0; i--)
            {
                reverse = reverse + word[i];
            }
           

            if (reverse == word)
            {
                Console.WriteLine("It's a palindrome!");
            }
            else
            {
                Console.WriteLine("It's not a palindrome!");
            }
            Console.ReadLine();
        }
    }
}