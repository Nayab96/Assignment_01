﻿namespace Question_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int i =1;
            Console.Write("Enter a number: ");
            int n = Convert.ToInt32(Console.ReadLine());

            for (i = 1; i <= 12; i++)
            {
                Console.WriteLine( i + "x" + n + " = " + i * n);
            }

            Console.ReadLine();
        }
    }
}