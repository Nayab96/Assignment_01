﻿namespace Question_16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter word:");
            string word = Console.ReadLine();

            int l = word.Length;
            string reverse = "";

            for (int i = l - 1; i >= 0; i--)
            {
                reverse = reverse + word[i];
            }

            Console.WriteLine(reverse);
            Console.ReadLine();
        }
    }
}