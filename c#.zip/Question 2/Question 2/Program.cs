﻿namespace Question_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name;
            Console.Write("Enter your name: ");
            name = Console.ReadLine();

            Console.WriteLine("Hello there " + name);
            Console.ReadLine();

        }
    }
}