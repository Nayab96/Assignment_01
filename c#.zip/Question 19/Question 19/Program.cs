﻿namespace Question_19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number: ");
            int n = Convert.ToInt32(Console.ReadLine());
   
            int i = 1;
            int r = 0;
            string result = "";
            for (i = 1; i <= n; i++)
            {
                result = result + i;
                Console.WriteLine(result);
            }
            Console.ReadLine();
        }
    }
}