﻿namespace Question_18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a number: ");
            int n = Convert.ToInt32(Console.ReadLine());

            int result = 0;

            for (int i = 1; i < n; i++)
            {
                if (n % i == 0)
                {
                    result = result + i;
                }
            }

            if (result == n)
            {
                Console.WriteLine("BAZZINGA! It's a perfect number!");
            }
            else
            {
                Console.WriteLine("it's NOT a perfect number!");
            }
        }
    }
}