﻿namespace Question_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 100;
            Console.WriteLine("Even Numbers are:");
            for (int i = 2; i < n; i++)
            {
                if (i%2 == 0)
                {
                    Console.WriteLine(i);
                }
            }
            
            Console.ReadLine();
        }
    }
}