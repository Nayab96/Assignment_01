﻿namespace Question_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] n = { 10, 34, 222 };


            if (n[0]> n[1] & n[0]> n[2])
            {
                Console.WriteLine(n[0] + " is the largest!");
            } else if (n[1] > n[0] & n[1] > n[0])
            {
                Console.WriteLine(n[1] + " is the largest!");
            } else
            {
                Console.WriteLine(n[2] + " is the largest!");
            }
            Console.ReadLine();
        }
    }
}