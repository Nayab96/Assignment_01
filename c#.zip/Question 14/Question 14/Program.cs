﻿namespace Question_14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the height of right angle: ");
            int n = Convert.ToInt32(Console.ReadLine());
            
            string star = "*";
            int i = 1;
            string result = "";

            for (i = 0; i <= n; i++)
            {
                result = result + star;
                Console.WriteLine(result);
            }
            Console.ReadLine();
        }
    }
}